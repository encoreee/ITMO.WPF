# WPF Futures Roadmap

WPF Futures is designed as a place to share sample features and controls and get community feedback on how compelling these are. You're welcome to use these features as starting blocks for more complete custom controls and features.

The latest is available [release:here](14962). We are eager to hear your feedback on the Futures features.  If you like these features, speak up! Please file bugs and general comments/questions in the [Issue Tracker](http://www.codeplex.com/wpf/WorkItem/List.aspx).

Released features include:
* Shader Effects
* Client Profile Configuration Designer
* [WPF Themes](WPF-Themes)

Some upcoming features include (subject to change):
* AnimatedStackPanel
* BreadcrumbBar
* ProgressBar