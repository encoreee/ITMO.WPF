# WPF Ribbon Preview

* **PLEASE LOOK FOR THE NEW RELEASE OF MICROSOFT RIBBON FOR WPF ON [MS DOWNLOADS](http://www.microsoft.com/downloads/details.aspx?FamilyID=2bfc3187-74aa-4154-a670-76ef8bc2a0b4&displaylang=en)**

**NOTE: The content posted here about the WPF Ribbon is provided as a convenience for developers using the WPF Toolkit who may also be interested in the WPF Ribbon. The WPF Ribbon preview is available for download on the Office UI Licensing site (a link to the site can be found towards the bottom of this page) and is NOT available for download from Codeplex.**

You can download a preview version of the WPF Ribbon from the [Office UI Licensing Site](http://msdn.microsoft.com/officeui)
# Follow the link above and click on "License the Office UI"
# Login using your Windows Live ID.  If you don't have a Windows Live ID already, you can create one for free
# Read and accept the Office UI License
## Licensing the Office UI (including the Ribbon) is free.  You must accept the license in order to access the WPF Ribbon download
# Click on the WPF Ribbon download button
# Accept the WPF Ribbon CTP License and follow the instructions to download the Ribbon binaries
# Click on the buttons for "2007 Microsoft Office Fluent UI Design Guidelines License" and "Microsoft Fluent Third Party Usage Guidelines" to download the Office UI Licensing Guidelines

* Check out the Ribbon Feature Walkthrough on [WindowsClient.net](http://windowsclient.net/wpf/wpf35/wpf-35sp1-ribbon-walkthrough.aspx)
* You can find more guidelines and best practices for Ribbon usage on MSDN [here](http://msdn.microsoft.com/en-us/library/cc872782.aspx).
* Sample Ribbon application available in the Hands-on-Lab available [here](http://windowsclient.net/downloads/folders/hands-on-labs/entry76491.aspx).
* Here's a six-part [Southridge Lab](Southridge-Lab) with sample application featuring Ribbon and DataGrid.