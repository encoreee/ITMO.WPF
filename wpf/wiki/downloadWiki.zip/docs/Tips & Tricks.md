# Tips & Tricks

**DataGrid/DatePicker Designer**
* [Design Time](Design-Time) Tips & Tricks

**Commonly Requested Features, How To's, and Samples**
Below find links to "How To" guides for implementing commonly requested features which are not available in V1 of the Toolkit components.
* DataGrid
	* [Column Selection](Column-Selection)
	* [Row Drag & Drop](Row-Drag-&-Drop)
	* [Single-Click Editing](Single-Click-Editing)
	* [Tri-State Sorting](http://blogs.msdn.com/vinsibal/archive/2008/08/29/wpf-datagrid-tri-state-sorting-sample.aspx)
	* [Clipboard Paste](http://blogs.msdn.com/vinsibal/archive/2008/09/19/wpf-datagrid-clipboard-paste-sample.aspx)
	* [Feature Walkthrough Sample](Feature-Walkthrough-Sample)
	* [Frozen row sample](http://blogs.msdn.com/vinsibal/archive/2008/10/31/wpf-datagrid-frozen-row-sample.aspx)
	* [Styling Rows and Columns based on Header conditions](http://blogs.msdn.com/vinsibal/archive/2008/09/16/wpf-datagrid-styling-rows-and-columns-based-on-header-conditions-and-other-properties.aspx)
	* [Basic DataGridComboBoxColumn Sample](http://blogs.msdn.com/vinsibal/archive/2008/10/31/wpf-datagrid-datagridcomboboxcolumn-v1-intro.aspx)
	* [New Item Template Sample](http://blogs.msdn.com/vinsibal/archive/2008/11/05/wpf-datagrid-new-item-template-sample.aspx)

**Known Issues**
Following is a list of known issues and work-around solutions where available.
* DataGrid
	* [Data Sources](Data-Sources)
	* [Sort Performance](Sort-Performance)
	* [SelectAll() Performance](SelectAll()-Performance)
	* [Validation](Validation)
* March 2009 Toolkit & the [VS Toolbox](VS-Toolbox)

**Resources for Testing Your WPF Application**
* [WPF Test Tools](http://wpf.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=30923) including [WPF Control Verifier](WPF-Control-Verifier) Version 0.1
* [TestApi](http://www.codeplex.com/TestApi) is an experimental library of test and utility APIs that enables developers and testers to test WPF applications, Windows Forms applications, .NET Framework applications, and Win32 applications. TestApi provides a set of simple, documented, componentized, and layered test APIs, which complement the [WPF Application Quality Guide](http://windowsclient.net/wpf/white-papers/wpf-app-quality-guide.aspx) and the materials available on the [WPF Testing blog](http://blogs.msdn.com/wpftesting). 

**Archived Information**
	* [DatePicker/VSM Memory Leak Known Issue Page](VSM-Memory-Leak).  This issue was fixed in [WPF Toolkit - January 2009 Release](http://www.codeplex.com/wpf/Release/ProjectReleases.aspx?ReleaseId=22567).
