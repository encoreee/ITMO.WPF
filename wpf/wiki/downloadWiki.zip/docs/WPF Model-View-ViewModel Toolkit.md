# WPF Model-View-ViewModel Toolkit

The Model-View-ViewModel toolkit is intended to introduce the Model-View-ViewModel design pattern for building WPF applications to the broad WPF developer community.

The toolkit includes:
* A Visual Studio 2008 template (Visual C# Express 2008 also supported)
* Documentation
	* General introduction to M-V-VM
	* Walkthrough using the VS template
* A complete WPF application demonstrating the M-V-VM pattern

You can download the toolkit on the [WPF Futures page](http://www.codeplex.com/wpf/Release/ProjectReleases.aspx?ReleaseId=14962).