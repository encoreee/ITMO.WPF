# WPF Control Verifier Version 0.1

## Introduction
WPF Control Verifier is a tool that verifies the correctness of WPF Controls.  This tool is geared towards WPF Control developers with the goal of providing a set of verifications that all controls can run and consume.  Version 0.1 includes one category for verification –  default style verification.  These tests verify that your control can be styled such that its dependency properties are inheriting or template binding correctly.  Future versions will include additional categories of verification.   

## Download
You can download the latest release of the WPF Control Verifier [here](http://wpf.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=30923).

## Feedback
This is our first beta and we will be updating it based on your feedback.  We have a planned set of features for future iterations but this will evolve based on your suggestions.  Please send your feedback to wpfcvt@microsoft.com.

## vNext
Here are some potential features for vNext:
* Theme verifications
	* Examine resources that are of interest to themes.  Verify that theming is applied correctly to the control.
* Visual State Manager verifications
	* Verify the visual states defined by the control are actionable.
* Stock control behavior verifications for custom stock controls
	* Base behavior verifications that can run on custom versions of the stock control to test conformity.  
* Performance heuristic verifications of control templates
	* Verify/Suggest usage of the chrome pattern.
* Resource usage verifications
	* Verify theme/application level resources are accessible across threads
	* Patterns and practices for use of ComponentResourceKey for parameterization
* Compatible Silverlight control verification
* Usability updates to the Default Style Verification category

## Acknowledgements
We would like to thank the following people for their contributions to this tool.
* Developer/Tester: Vincent Sibal, Alexis Roosa
* Reviewers: Ivo Manolov, Varsha Mahadevan, Vamsee Potharaju
* Editor: David Carlson 
* Additional feedback: David Anson, Jonathan Wills, Weifeng Yao
