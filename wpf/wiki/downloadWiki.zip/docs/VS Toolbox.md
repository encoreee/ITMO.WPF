# VS Toolbox Known Issues

Some users have reported that after installing the March 2009 WPF Toolkit Release, the Toolkit components which are available in the Visual Studio Toolbox do not function properly.  When trying to drag a control onto the design surface, you may not be able to drop the controls (you get a "no" cursor), and double-clicking the control in the Toolbox may have no effect.  If you encounter this issue, the workaround is to right-click on the Toolbox and choose "Reset Toolbox" in the context menu.  It will take a few moments (1-2 minutes) to reset, and then the controls should be working as normal.

We are still investigating the reason for this issue and will update this page when we have more information.