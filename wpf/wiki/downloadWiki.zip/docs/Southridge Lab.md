# Southridge Hands-on-Lab

Southridge is an extensive hands-on-lab for WPF developers.  The six-part lab includes the following sections:
# Fundamentals
# Custom Controls
# Styling
# Ribbon
# DataGrid
# Databinding

Download the Southridge lab on the [WPF Futures page](http://www.codeplex.com/wpf/Release/ProjectReleases.aspx?ReleaseId=14962).

Please note that in order to use the Ribbon sections of this lab, you must install the RibbonControlsLibrary.dll from the Office UI Licensing Site using the instructions on [this page](http://www.codeplex.com/wpf/Wiki/View.aspx?title=WPF%20Ribbon%20Preview).  Due to licensing requirements, RibbonControlsLibrary.dll is not included with the Southridge lab's zip file and must be downloaded separately.