# Quality Bands 

## Experimental 
Experimental components are intended for evaluation purposes. The main goal of these components is to provide an opportunity for feedback during the earliest stages of development. This feedback will help decide the future of these components. Development of an experimental component may end at any point so it may not be included in future releases.

## Preview 
Preview components are intended to meet most basic usage scenarios. While in the Preview Quality Band, these components may have a moderate number of breaking API or behavior changes in response to customer feedback and as we learn more about how they will be used. Customers are likely to encounter bugs and functionality issues for non-mainline scenarios. Preview is similar to "Alpha" quality in many traditional projects.

## Stable 
Stable components are suitable for the vast majority of usage scenarios and will have incorporated most major design and functionality feedback. They are designed to address over 90% of customer scenarios and will continue evolving via limited bug fixes and fit-and-finish work. Stable is similar to "Beta" in other projects. Stable components will have a very small number of breaking API or behavior changes when feedback demands it.

## Mature 
Mature components are ready for full release, meeting the highest levels of quality and stability. Future releases of mature components will maintain a high quality bar with no breaking changes except when such changes are necessary to make them more secure or guarantee future compatibility. Customers should be confident using mature components, knowing that when they upgrade from one version of the WPF Toolkit to a newer version it will be a quick and easy process. Due to the heavy focus on backward compatibility between versions, the bar for fixing bugs found in mature components is also considerably higher than any other Quality Band.
