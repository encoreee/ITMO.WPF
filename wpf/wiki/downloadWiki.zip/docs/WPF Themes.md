# WPF Themes

An updated collection of seven themes replaces the original nine WPF Themes. Some of the issues with the original themes have been addressed in this update. Download the WPF Themes in the [WPF Futures](http://wpf.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=14962) release.  This collection of themes can also be found in the [Silverlight Toolkit](http://silverlight.codeplex.com/Wiki/View.aspx?title=Silverlight%20Toolkit%20Overview%20Part%203). 

![](WPF Themes_WPFThemesV2.jpg)

## How to Use the WPF Themes

How to use the WPF Themes in your application:

**Resource dictionary**  You can use the themes as a resource dictionary.  Add the xaml file of the desired theme to your project (in Visual Studio, right-click on the project in the Solution Explorer, choose Add --> Existing File and select the appropriate .xaml file) and make sure your project also includes a reference to WPFToolkit.dll (the themes depend on VSM).  In App.xaml, add a reference to the desired theme to the Application.Resources.  For example,

{{
<Application x:Class="ThemesSample.App"
    xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
    xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
    StartupUri="Window1.xaml">
    <Application.Resources>
        <ResourceDictionary Source="ExpressionDark.xaml"/>
    </Application.Resources>
</Application>
}}
## Themes Quick Reference
| ![Expression Dark Thumbnail](WPF Themes_thumbExpresssionDark.png) | **Expression Dark** | ![Expression Light Thumbnail](WPF Themes_thumbExpresssionLight.png) | **Expression Light** | ![Whistler Blue Thumbnail](WPF Themes_WhistlerBlue.png) | **Whistler Blue** |
| ![Shiny Red Thumbnail](WPF Themes_thumbRubyDarkRed.png) | **Shiny Red** | ![Shiny Blue Thumbnail](WPF Themes_thumbRubyDarkBlue.png) | **Shiny Blue** | ![Bureau Blue Thumbnail](WPF Themes_BureauBlue.png) | **Bureau Blue** |
| ![Bureau Black Thumbnail](WPF Themes_BureauBlack.png) | **Bureau Black** |