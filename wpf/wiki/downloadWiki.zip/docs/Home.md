# Welcome to Windows Presentation Foundation!
This project is the portal for accessing the WPF Toolkit and the WPF Futures releases.
* Check out the **[WPF Platform Updates](WPF-Platform-Roadmap)** to learn about the new features in the latest Platform release.
	* Documentation relating to the WPF Toolkit and Futures now available on [WindowsClient.net](http://windowsclient.net/wpf/)
* The **[WPF Toolkit](http://www.codeplex.com/wpf/Release/ProjectReleases.aspx)** is a collection of WPF features and components that are being made available outside of the normal .NET Framework ship cycle.  The WPF Toolkit not only allows users to get new functionality more quickly, but allows an efficient means for giving feedback to the product team.  Many of the features will be released with full source code as well. The [Toolkit Roadmap](Toolkit-Roadmap) outlines some of the upcoming features we have planned.
	* **New!** **February 2010 Release** includes Previews of AutoCompleteBox, Accordion, and Rating controls, and bug fixes
	* [Beta MSDN Documentation for Toolkit components!](http://wpf.codeplex.com/Thread/View.aspx?ThreadId=58833)
	* Bug fixes for common issues, including issues in DataGrid, Calendar/DatePicker, VSM controls and UI Automation
	* Preview of Chart controls, AutoCompleteBox, Accordion, and Rating controls
* **[release:WPF Futures](14962)** includes sample controls and features, many of which are being considered for the Toolkit.  Check out the [Futures Roadmap](Futures-Roadmap) to see some of the features we have planned.
	* Check out the Client Profile Configuration Designer
	* Try the [Southridge](Southridge-Lab) sample application and Hands-on-Lab
	* [WPF Themes](WPF-Themes) have been updated and includes fixes for some issues. The updated version does not include the 'TwilightBlue' and 'BubbleCream' Themes, and can be used as a ResourceDictionary only. Check it out! Please note that the themes are provided as-is as a sample/starting point to build from and are not considered supported by the WPF Product Team. 
	* [WPF Model-View-ViewModel Toolkit](WPF-Model-View-ViewModel-Toolkit)
* **[WPF Ribbon Preview](http://www.codeplex.com/wpf/Wiki/View.aspx?title=WPF%20Ribbon%20Preview)** available on the Office UI Licensing Site!
* The **[Tips & Tricks](http://www.codeplex.com/wpf/Wiki/View.aspx?title=Tips%20%26%20Tricks&referringTitle=Home)** section contains resources to help you with your WPF application, including:
	* DataGrid How To's, Samples, and Known Issues
* [TestApi (v0.4)](http://www.codeplex.com/TestApi) - the latest revision of the API library for building automated tests.
* [WPF Test Tools](http://wpf.codeplex.com/Release/ProjectReleases.aspx?ReleaseId=30923) release including [WPF Control Verifier](WPF-Control-Verifier) Version 0.1.
* [The WPF Shell Integration Library](http://code.msdn.microsoft.com/WPFShell) is available on MSDN code gallery. 
	* Offers a variety of Windows Shell Integration features for your WPF application.  Currently featuring support for 3.x applications for the new [Windows 7 Taskbar and Jumplist APIs](http://msdn.microsoft.com/en-us/library/system.windows.shell(VS.100).aspx), in a highly compatible mirror of these features already included in the .net Framework v4.0.
* **New!** [The Microsoft XAML Toolkit CTP - July 2010](http://code.msdn.microsoft.com/XAML/Wiki/View.aspx?title=Microsoft%20XAML%20Toolkit%20%20CTP%20-%20July%202010&referringTitle=Home) is available on code gallery.
	* Microsoft XAML Toolkit is a set of libraries enabling easier manipulation and analysis of XAML for .NET 4.0 and Silverlight.
The WPF Codeplex site is part of the [Microsoft Shared Source Initiative](http://www.microsoft.com/resources/sharedsource/default.mspx).  For more information about the Shared Source initiative and community contribution rules, please see the [Shared Source](Shared-Source) wiki page.