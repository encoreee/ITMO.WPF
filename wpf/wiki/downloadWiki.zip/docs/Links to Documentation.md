# Links to Documentation for WPF Toolkit Components

Official MSDN documentation about the controls and features in the WPF Toolkit will be available with .NET 4.0.  In the interim, we encourage you to search and post questions to the [Discussions](http://wpf.codeplex.com/Thread/List.aspx) forum on this site.  We've also provided some additional resources which you may find useful:

* [Tips & Tricks](Tips-&-Tricks) for using the WPF Toolkit components

* [Beta MSDN Documentation](http://wpf.codeplex.com/Thread/View.aspx?ThreadId=58833) for Toolkit components

* DataGrid, DatePicker, & VSM documentation on [WindowsClient.net](http://windowsclient.net/wpf/), including:
	* [DataGrid Feature Walkthrough](http://windowsclient.net/wpf/wpf35/wpf-35sp1-toolkit-datagrid-feature-walkthrough.aspx)
	* [DatePicker & Calendar Feature Walkthrough](http://windowsclient.net/wpf/wpf35/wpf-35sp1-toolkit-calendar-datepicker-walkthrough.aspx)
	* [Visual State Manager Overview](http://windowsclient.net/wpf/wpf35/wpf-35sp1-toolkit-visual-state-manager-overview.aspx). 
	* [Ribbon Feature Walkthrough](http://windowsclient.net/wpf/wpf35/wpf-35sp1-ribbon-walkthrough.aspx)
	* [Hands-on-Lab: "What's coming in WPF: DataGrid, Ribbon, & VSM"](http://windowsclient.net/downloads/folders/hands-on-labs/entry76491.aspx)
	* [Visual State Manager in Expression Blend](http://blogs.msdn.com/expression/archive/2008/10/30/blend-2-sp1-wpf-toolkit-visual-state-manager-for-wpf.aspx). 

* Six-part [Southridge Lab](Southridge-Lab) with sample application featuring DataGrid and Ribbon.