# DataGrid Design Time

A design time experience is available for the WPF DataGrid in the Visual Studio Designer (codename 'Cider').  This design time will allow you to add/remove columns from your Columns collection and modify the properties of individual columns and the DataGrid itself.  Simply right-click on the DataGrid in the designer and use the options under the "DataGrid" menu item.

In order to use the designer, you must install the WPF Toolkit using the WPFToolkit.msi installer, which will place design time dlls in a known location where the designer will look for them.  If the dlls are not in this location, you will not be able to use DataGrid in the designer.

**Setting an ItemsSource**
In order to edit bound columns in the Columns collection through the designer, the DataGrid must have a valid ItemsSource set (the designer can be used with unbound columns without setting the ItemsSource).  There is a limitation in the designer whereby you cannot bind to properties on the element you are designing.  If your DataGrid is not showing any columns in the Add/Remove Columns dialog but your project compiles and runs, your ItemsSource is most likely hitting this issue.  To learn how to solve this issue, please visit the [Design Time ItemsSource](Design-Time-ItemsSource) page.

**Viewing Data at Design Time**
It is possible for to view the data in your DataGrid in the designer.   If the DataGrid control has a DataContext with data in it and the control is data bound, the data will display.  You can learn more about getting your data to display at design time in this [blog post](http://karlshifflett.wordpress.com/2008/10/11/viewing-design-time-data-in-visual-studio-2008-cider-designer-in-wpf-and-silverlight-projects/).
