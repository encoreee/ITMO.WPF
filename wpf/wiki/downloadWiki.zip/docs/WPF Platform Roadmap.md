# WPF Platform Updates

The latest release of the .NET Framework (version [3.5 Service Pack 1](http://www.microsoft.com/downloads/details.aspx?FamilyID=ab99342f-5d1a-413d-8319-81da479ab0d7&DisplayLang=en)) includes these exciting new improvements:
* **Application Startup and Working Set Performance Improvements**, including significant performance improvements to the CLR to enable 10-40% faster application startup times.
* **New .NET Framework Client Profile Setup Package**, a new setup installer that enables a smaller, faster, and simpler installation experience for .NET client applications on machines that do not already have the .NET Framework installed.
* **New .NET Framework Setup Bootstrapper for Client Applications**, a new "bootstrapper" component that you can use with client applications to help automate making sure that the right version of the .NET Framework is installed.  
* **ClickOnce Client Application Deployment Improvements**.
* **Performance Improvements**, specifically in the graphics and data scalability arenas.
* **Data Improvements**
* **Extensible Shader Effects**
* **WPF Interoperability with Direct3D**
* **Visual Studio 2008 for WPF Improvements**

For more information, please visit the WPF homepage on [WindowsClient.net](http://windowsclient.net/wpf/).

 