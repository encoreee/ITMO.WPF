# WPF Toolkit Roadmap

The WPF Toolkit is a collection of WPF features and components that are being made available outside of the normal .NET Framework ship cycle.  The WPF Toolkit not only allows users to get new functionality more quickly, but allows an efficient means for giving feedback to the product team.  Many of the features will be released with full source code as well.  Over time, some of these features may be moved into the .NET Framework, based on readiness and customer feedback.

Find our latest release [here](http://www.codeplex.com/wpf/Release/ProjectReleases.aspx). We are eager to hear your feedback on the Toolkit features.  Please file bugs and general comments/questions in the [Issue Tracker](http://www.codeplex.com/wpf/WorkItem/List.aspx).

Some recently released features include:
* DataGrid
* DatePicker/Calendar
* VisualStateManager (VSM)

Planned/Upcoming features include (subject to change):
* Chart controls - Check out a preview [here](http://blogs.msdn.com/delay/archive/2009/03/20/silverlight-charting-remains-just-a-click-away-and-runs-on-wpf-too-chartbuilder-sample-and-source-code-updated-for-charting-s-march-09-release.aspx)
* Autocomplete
* NumericUpDown