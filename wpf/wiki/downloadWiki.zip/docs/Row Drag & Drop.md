# DataGrid Tips & Tricks: Row Drag & Drop

Drag and drop of rows is not enabled by default in the DataGrid, but you can implement it with just a few simple steps.  

1. Paste the methods below {"(myDataGrid_MouseMove, DataGrid_CheckDropTarget, myDataGrid_Drop)"} into the code behind
2. Assign the event handler methods to the MouseMove, DragEnter, DragLeave, DragOver, and Drop events on the DataGrid like below
3. Apply the Style below to the DataGrid's RowStyle or ItemContainerStyle (ItemContainerStyle and RowStyle are equivalent properties)

{{
    <!--
      DRAG AND DROP
      MouseMove, DragEnter, DragLeave, DragOver, and Drop were added for drag-and-drop support.
    -->
    <dg:DataGrid x:Name="myDataGrid" 
                 MouseMove="myDataGrid_MouseMove"
                 DragEnter="DataGrid_CheckDropTarget"
                 DragLeave="DataGrid_CheckDropTarget"
                 DragOver="DataGrid_CheckDropTarget"
                 Drop="myDataGrid_Drop"
                 >

     <dg:DataGrid.RowStyle>
        <!--
          DRAG AND DROP
          Enables rows as drop targets.
        -->
        <Style TargetType="{x:Type dg:DataGridRow}">
          <Setter Property="AllowDrop" Value="True" />
        </Style>
      </dg:DataGrid.RowStyle>       



     //
     // DRAG AND DROP
     //
     private void myDataGrid_MouseMove(object sender, MouseEventArgs e)
     {
         if (e.LeftButton == MouseButtonState.Pressed)
         {
             Point currentPosition = e.GetPosition(myDataGrid);

             object selectedItem = myDataGrid.SelectedItem;
             if (selectedItem != null)
             {
                 DataGridRow container = (DataGridRow)myDataGrid.ItemContainerGenerator.ContainerFromItem(selectedItem);
                 if (container != null)
                 {
                     DragDropEffects finalDropEffect = DragDrop.DoDragDrop(container, selectedItem, DragDropEffects.Move);
                     if ((finalDropEffect == DragDropEffects.Move) && (_targetItem != null))
                     {
                         // A Move drop was accepted
                         Person selectedPerson = (Person)selectedItem;
                         Person targetPerson = (Person)_targetItem;

                         int oldIndex = _people.IndexOf(selectedPerson);
                         int newIndex = _people.IndexOf(targetPerson);
                         _people.Move(oldIndex, newIndex);

                         _targetItem = null;
                     }
                 }
             }
         }
     }

     private void DataGrid_CheckDropTarget(object sender, DragEventArgs e)
     {
         if (FindVisualParent<DataGridRow>(e.OriginalSource as UIElement) == null)
         {
             e.Effects = DragDropEffects.None;
         }
         e.Handled = true;
     }

     private void myDataGrid_Drop(object sender, DragEventArgs e)
     {
         e.Effects = DragDropEffects.None;
         e.Handled = true;

         // Verify that this is a valid drop and then store the drop target
         DataGridRow container = FindVisualParent<DataGridRow>(e.OriginalSource as UIElement);
         if (container != null)
         {
             _targetItem = container.DataContext;
             e.Effects = DragDropEffects.Move;
         }
     }   
}}